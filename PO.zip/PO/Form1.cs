﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PO
{
    public partial class Form1 : Form
    {

        public NpgsqlConnection con;
        int id;
        int id_cashier;
        string date_;
        string year_;
        float prof;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        DataSet ds1 = new DataSet();
        DataTable dt2 = new DataTable();

        public void Update()
        {
            String sql = "Select * from sales_log";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "id_заказа";
            dataGridView1.Columns[1].HeaderText = "id_фильма";
            dataGridView1.Columns[2].HeaderText = "id_кассира";
            dataGridView1.Columns[3].HeaderText = "Дата продажи";
            dataGridView1.Columns[4].HeaderText = "Сумма покупки";
            dataGridView1.Columns[5].HeaderText = "Количество экземпляров";
            this.StartPosition = FormStartPosition.CenterScreen;
            List<Client> list = new List<Client>();
            string request = "Select * from cashier";
            NpgsqlCommand cmd = new NpgsqlCommand(request, con);
            using (NpgsqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string str = reader["id_cashier"].ToString();
                    int id_c = Convert.ToInt32(str);
                    string name = reader["surname"].ToString() + " " + reader["name"].ToString()[0];
                    Client client = new Client(id_c, name);
                    list.Add(client);
                }
            }
            comboBox1.DataSource = list;
            comboBox1.DisplayMember = "name";
            comboBox1.ValueMember = "id";

            List<int> numbers = Enumerable.Range(1, 12).ToList();
            comboBox2.DataSource = numbers;

            List<int> years = Enumerable.Range(2015, 11).ToList();
            comboBox3.DataSource = years;
        }

        public class Client
        {
            public int id { get; set; }
            public string name { get; set; }

            public Client(int id, string name)
            {
                this.id = id;
                this.name = name;
            }
        }

        public void MyLoad()
        {
            this.StartPosition = FormStartPosition.CenterScreen;
            con = new NpgsqlConnection("Server=localhost; Port=5432; UserID=postgres; Password=postpass; Database=filmoteka");
            con.Open();
            Update();
        }

        public void naclad()
        {
            String sql = "Select * from invoice ORDER BY id_invoice DESC LIMIT 1";
            NpgsqlDataAdapter da1 = new NpgsqlDataAdapter(sql, con);
            ds1.Reset();
            da1.Fill(ds1);
            dt2 = ds1.Tables[0];
            dataGridView2.DataSource = dt2;
            dataGridView2.Columns[0].HeaderText = "id_накладной";
            dataGridView2.Columns[1].HeaderText = "id_бухгалтера";
            dataGridView2.Columns[2].HeaderText = "Месяц";
            dataGridView2.Columns[3].HeaderText = "Год";
            dataGridView2.Columns[4].HeaderText = "Прибыль";
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        public Form1()
        {
            InitializeComponent();
            MyLoad();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<float> list = new List<float>();
            string req = string.Format("Select * from sales_log where id_cashier = {0} and EXTRACT(MONTH FROM date_of_sale) = {1} and EXTRACT(YEAR FROM date_of_sale) = {2}", id_cashier, Convert.ToInt32(date_), Convert.ToInt32(year_));
            NpgsqlCommand cmd2 = new NpgsqlCommand(req, con);
            using (NpgsqlDataReader reader = cmd2.ExecuteReader())
            {
                while (reader.Read())
                {
                    float amount = float.Parse(reader["purchase_amount"].ToString());
                    int quant = Convert.ToInt32(reader["quantity"].ToString());
                    list.Add(amount * quant);
                }
            }
            prof = list.Sum();

            
            NpgsqlCommand com2 = new NpgsqlCommand("INSERT INTO invoice (id_accountant, month, year, profit) VALUES (:id_ac, :month, :year, :prof)", con);
            com2.Parameters.AddWithValue("id_ac", 1);
            com2.Parameters.AddWithValue("month", Convert.ToInt32(date_));
            com2.Parameters.AddWithValue("year", Convert.ToInt32(year_));
            com2.Parameters.AddWithValue("prof", prof);
            com2.ExecuteNonQuery();

            naclad();
        }
        private void label3_Click(object sender, EventArgs e)
        {
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Client client = (Client)comboBox1.SelectedItem;
            id_cashier = client.id;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            date_ = comboBox2.SelectedItem.ToString();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            year_ = comboBox3.SelectedItem.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sql = string.Format("Select * from sales_log where id_cashier = {0} and EXTRACT(MONTH FROM date_of_sale) = {1} and EXTRACT(YEAR FROM date_of_sale) = {2} ", id_cashier, Convert.ToInt32(date_), Convert.ToInt32(year_));
            NpgsqlDataAdapter cm = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            cm.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "id_заказа";
            dataGridView1.Columns[1].HeaderText = "id_фильма";
            dataGridView1.Columns[2].HeaderText = "id_кассира";
            dataGridView1.Columns[3].HeaderText = "Дата продажи";
            dataGridView1.Columns[4].HeaderText = "Сумма покупки";
            dataGridView1.Columns[5].HeaderText = "Количество экземпляров";
            this.StartPosition = FormStartPosition.CenterScreen;
        }
    }
}
